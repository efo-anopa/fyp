<?php
    $dbuser="root";
    $dbpass="";
    $host="localhost";
    $db="offcampus";
    $mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>