-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 30, 2023 at 09:50 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `offcampus`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `hostel_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(300) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `updation_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `hostel_id`, `email`, `password`, `reg_date`, `updation_date`) VALUES
(1, 'zenonAdmin', 1, 'zenon@mail.com', '07731b058063ad0818da2d5f3fa2bbd1', '2023-08-27 23:58:47', '0000-00-00'),
(2, 'blueSkiesAdmin', 2, 'blues@mail.com', '41b5807285dd36c1527e6437b75e46d7', '2023-08-27 23:58:47', '0000-00-00'),
(3, 'perryAdmin', 3, '', '', '2023-08-28 00:11:11', '0000-00-00'),
(4, 'comityAdmin', 4, '', '', '2023-08-28 00:11:11', '0000-00-00'),
(5, 'asedaAdmin', 5, '', '', '2023-08-28 00:11:11', '0000-00-00'),
(6, 'theoAdmin', 6, '', '', '2023-08-28 00:11:11', '0000-00-00'),
(7, 'edwinAdmin', 7, '', '', '2023-08-28 00:11:11', '0000-00-00'),
(8, 'francisAdmin', 8, '', '', '2023-08-28 00:11:11', '0000-00-00'),
(9, 'freemanAdmin', 9, '', '', '2023-08-28 00:11:11', '0000-00-00'),
(10, 'peculiarAdmin', 10, '', '', '2023-08-28 00:11:11', '0000-00-00'),
(11, 'goodwillAdmin', 11, '', '', '2023-08-28 00:11:11', '0000-00-00'),
(12, 'heavensAdmin', 12, '', '', '2023-08-28 00:11:11', '0000-00-00'),
(13, 'joyAdmin', 13, '', '', '2023-08-28 00:11:11', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `adminlog`
--

CREATE TABLE `adminlog` (
  `id` int(11) NOT NULL,
  `adminid` int(11) NOT NULL,
  `ip` varbinary(16) NOT NULL,
  `logintime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `complaint`
--

CREATE TABLE `complaint` (
  `id` int(11) NOT NULL,
  `complaint` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `sender_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `course_code` varchar(255) NOT NULL,
  `course_sn` varchar(255) NOT NULL,
  `course_fn` varchar(255) NOT NULL,
  `posting_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_code`, `course_sn`, `course_fn`, `posting_date`) VALUES
(1, 'BTH123', 'B.Tech', 'Bachelor  Of Technology', '2020-09-23 00:45:13'),
(2, 'BCOM18', 'B.Com', 'Bachelor Of Commerce ', '2020-09-23 00:45:13'),
(3, 'BSC296', 'BSC', 'Bachelor  of Science', '2020-09-23 00:45:13'),
(4, 'BCOA55', 'BCA', 'Bachelor Of Computer Application', '2020-09-23 00:45:13'),
(5, 'MCA001', 'MCA', 'Master of Computer Application', '2020-09-23 00:47:13'),
(6, 'MBA777', 'MBA', 'Master In Business Administration', '2020-09-23 00:54:13'),
(7, 'BE069', 'BE', 'Bachelor of Engineering', '2020-09-23 00:59:13'),
(8, 'BIT353', 'BIT', 'Bachelors In Information Technology', '2021-03-07 06:59:05'),
(9, 'MIT005', 'MIT', 'Master of Information Technology', '2022-04-03 13:03:19');

-- --------------------------------------------------------

--
-- Table structure for table `hostel`
--

CREATE TABLE `hostel` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `location` varchar(30) NOT NULL,
  `digi_address` varchar(15) NOT NULL,
  `description` text NOT NULL,
  `imageURL` varchar(300) NOT NULL,
  `mapEmbed` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hostel`
--

INSERT INTO `hostel` (`id`, `name`, `location`, `digi_address`, `description`, `imageURL`, `mapEmbed`) VALUES
(1, 'Zenon Hostel', 'North Legon', 'GM-048-7644', 'Facilities: TV Room, Self meter, AC\r\nPrices: ₵2200 for 4-in-1, ₵3000 for 2-in-1, ₵4000 for 1-in-1\r\nElectricity and water are catered for\r\n', '\\assets\\images\\hostels\\zenon.jpg', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3970.2875097285723!2d-0.18337122501398584!3d5.6715076943100176!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf9cf3db66aa7d%3A0xf3e698a4aa7c3770!2sZenon%20Hostel!5e0!3m2!1sen!2sde!4v1693224855135!5m2!1sen!2sde'),
(2, 'Blue Skies Hostel', 'Haatso (Agbogba)', 'GE-281-9303', 'Facilities: TV Room\r\nPrices: ₵2200 for 2-in-1, ₵2500 for 1-in-1, ₵4000 for 1-in-1\r\nElectricity and water are catered for\r\n', '\\assets\\images\\hostels\\blue-skies.jpg', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15881.188304540152!2d-0.20237276072217095!3d5.670117405694311!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf9c5f1d0cb3c3%3A0x440bed9a9d54af!2sBlue%20Skies%20Hostel!5e0!3m2!1sen!2sde!4v1693227262253!5m2!1sen!2sde'),
(3, 'Perry\'s Hostel', 'Haatso(Agbogba)', '', 'Prices: ₵4000 for 2-in-1 with AC, ₵3500 for 2-in-1 with no AC, ₵7000 for 1-in-1 with no AC, ₵8000 with AC\r\nElectricity and water are catered for\r\n', '\\assets\\images\\hostels\\perry.jpg', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3970.206512081564!2d-0.17038902913232964!3d5.683265519780927!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf9df97af67f49%3A0x9579eae921d4fb58!2sPerry%E2%80%99s%20Hostel!5e0!3m2!1sen!2sde!4v1693227537729!5m2!1sen!2sde'),
(4, 'Comity Hostel', '', '', 'Facilities: TV Room\r\nPrices: ₵2200 for 2-in-1, ₵2500 for 1-in-1, ₵4000 for 1-in-1\r\nElectricity and water are catered for\r\n', '\\assets\\images\\hostels\\comity.jpg', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3970.2775868350514!2d-0.17898742582197705!3d5.672949432464267!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf9d1f0ce602a9%3A0xa367da2fe2cd79b9!2sComity%20hostel!5e0!3m2!1sen!2sde!4v1693226728048!5m2!1sen!2sde'),
(5, 'Aseda Hostel', 'North Legon', '', 'Facilities: TV Room, kitchenette per room, reading room\r\nPrices: ₵2200 for 4-in-1, ₵2775 for 3-in-1, ₵3000 for 2-in-1, ₵4000 for 1-in-1\r\nElectricity and water are catered for\r\n', '\\assets\\images\\hostels\\aseda.jpg', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d127042.2725333768!2d-0.23677972988040252!3d5.70288036379415!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf9d0b6949f147%3A0x2c7f6c4a9c724beb!2sAseda%20Hostel%20Annex%20A!5e0!3m2!1sen!2sde!4v1693228664395!5m2!1sen!2sde'),
(6, 'Mr. Theophilus Mamiya Property', 'North Legon', 'GM-031-5283', 'Prices: ₵2700 for 2-in-1, ₵4500 for 1-in-1\r\nElectricity: Student bears cost \r\nWater: Landlord bears cost \r\n', '\\assets\\images\\hostels\\theo-mamiya.jpg', 'https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d834.6472710965759!2d-0.17709400733339772!3d5.67341451649851!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sus!4v1693423712660!5m2!1sen!2sus'),
(7, 'Dr. Edwin Amonoo\'s Property', 'North Legon', 'GM-048-0227', 'Facilities: TV with DSTV, Table Top fridges, Wi-Fi\r\nPrices: ₵1680 per month for 2-in-1 with AC, ₵1080 for 2-in-1 without AC, \r\nElectricity and water are catered for\r\n\r\n', '\\assets\\images\\hostels\\edwin.jpg', 'https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d1985.145859505272!2d-0.184042!3d5.670896!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sus!4v1693423995428!5m2!1sen!2sus'),
(8, 'St. Francis Center', 'Haatso(Agbogba)', 'GE-191-1387', 'Facilities: TV with DSTV, Wi-Fi\r\nPrices: ₵2000, ₵2500, ₵3000  for 2-in-1, specific price depends on stuff in room\r\nElectricity and water are catered for\r\n', '\\assets\\images\\hostels\\st-francis.jpg', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3970.1803331984743!2d-0.2041808258219329!3d5.687060532319532!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf9dbddffcc6f3%3A0x9cb2ffc857461ce!2sSt.%20Francis%20Centre!5e0!3m2!1sen!2sus!4v1693424066198!5m2!1sen!2sus'),
(9, 'Mr. Freeman Dasoberii\'s Property', 'Madina', 'GM-017-4733', 'Facilities: TV room with DSTV, Wi-Fi\r\nPrices: ₵2500 for 3-in 1, ₵2200 for 4-in-1, ₵3000  for 2-in-1\r\nElectricity is handled by student and water is catered for by students\r\n', '\\assets\\images\\hostels\\mr-freeman.jpg', 'https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d1985.1294518210184!2d-0.173038!3d5.675663!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sus!4v1693424258799!5m2!1sen!2sus'),
(10, 'P-Cular Heights', 'Madina', '', 'Facilities: Wi-Fi, generator, minimart, elevator, study room, CCTV, cafeteria, laundry\r\nPrices: ₵2500 for 3-in 1, ₵2200 for 4-in-1, ₵5000  for 2-in-1\r\nElectricity is handled by student and water is catered for by students\r\n', '\\assets\\images\\hostels\\p-cular.jpg', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3970.3268757989767!2d-0.16737802582203626!3d5.6657844325376505!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf9d1bc997eca1%3A0xf8d8d4c6ac17b618!2sP-Cular%20heights!5e0!3m2!1sen!2sde!4v1693228800301!5m2!1sen!2sde'),
(11, 'Goodwill Plaza Hostel', 'UPSA', 'GA-517-2033', 'Facilities: Game center, gate to stairs can only be opened by fingerprints of residents.\r\nPrices: ₵3000 in 1-in-1, ₵2500 in 2-in-1, ₵2000  for 3-in-1,₵1750  for 4-in-1 \r\nElectricity is catered for by students\r\n', '\\assets\\images\\hostels\\goodwill-plaza.jpg', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5269.298731575296!2d-0.1684225568141448!3d5.657807938534701!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf9cbce9902da7%3A0xd8aae6bd9739970!2sGoodwill%20Plaza%20Hostel!5e0!3m2!1sen!2sus!4v1693424376317!5m2!1sen!2sus'),
(12, 'Heaven\'s Gate Hostel', 'UPSA', 'GA-517-3803', 'Facilities: CCTV, polytank for backup water supply.\r\n3 blocks, one with reading room\r\nPrices: ₵5000 per year  for 4-in-1 \r\nElectricity is catered for by students\r\n', '\\assets\\images\\hostels\\heaven\'s-gate.jpg', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.4712627278636!2d-0.16645592419884842!3d5.657597713702431!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf9cbcaf5cd87b%3A0x10ffa2c6eb7d91db!2sHeaven&#39;s%20Gate%20Hostel!5e0!3m2!1sen!2sus!4v1693424456204!5m2!1sen!2sus'),
(13, 'Joy Hostel', 'UPSA', 'GA-516-6392', 'Facilities: Kitchen per floor, study room\r\nPrices: ₵1700 for 4-in-1 per semester\r\nElectricity, water and gas are catered for.\r\nHostel is locked at 11pm and opened at 5pm.\r\n', '\\assets\\images\\hostels\\joy.jpg', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31763.126728063813!2d-0.19272579853214394!3d5.6564725!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf9ca49bef8f3f%3A0xe11252a38c361cca!2sJoy%20Hostel!5e0!3m2!1sen!2sus!4v1693424625115!5m2!1sen!2sus');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `hostel_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `seater` int(11) NOT NULL,
  `feespm` int(11) NOT NULL,
  `stayfrom` date NOT NULL,
  `duration` int(11) NOT NULL,
  `course` varchar(500) NOT NULL,
  `firstName` varchar(500) NOT NULL,
  `middleName` varchar(500) NOT NULL,
  `lastName` varchar(500) NOT NULL,
  `gender` varchar(250) NOT NULL,
  `contactno` varchar(11) NOT NULL,
  `emailid` varchar(500) NOT NULL,
  `egycontactno` bigint(11) NOT NULL,
  `guardianName` varchar(500) NOT NULL,
  `guardianRelation` varchar(500) NOT NULL,
  `guardianContactno` bigint(11) NOT NULL,
  `corresAddress` varchar(500) NOT NULL,
  `corresCIty` varchar(500) NOT NULL,
  `corresState` varchar(500) NOT NULL,
  `corresPincode` int(11) NOT NULL,
  `pmntAddress` varchar(500) NOT NULL,
  `pmntCity` varchar(500) NOT NULL,
  `pmnatetState` varchar(500) NOT NULL,
  `pmntPincode` int(11) NOT NULL,
  `postingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `hostel_id` int(11) NOT NULL,
  `seater` int(11) NOT NULL,
  `room_no` varchar(7) NOT NULL,
  `occu_gender` varchar(10) NOT NULL,
  `fees` int(11) NOT NULL,
  `posting_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(11) NOT NULL,
  `State` varchar(150) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `State`) VALUES
(1, 'Alabama'),
(2, 'Alaska'),
(3, 'Arizona'),
(4, 'Arkansas'),
(5, 'California'),
(6, 'Colorado'),
(7, 'Connecticut'),
(8, 'Delaware'),
(9, 'Florida'),
(10, 'Georgia'),
(11, 'Hawaii'),
(12, 'Idaho'),
(13, 'Illinois'),
(14, 'Iowa'),
(15, 'Kansas'),
(16, 'Kentucky'),
(17, 'Louisiana'),
(18, 'Maine'),
(19, 'Marryland'),
(20, 'Massachusetts'),
(21, 'Michigan'),
(22, 'Minnesota'),
(23, 'Mississippi'),
(24, 'Missouri'),
(25, 'Nevada'),
(26, 'New Jersey'),
(27, 'New York'),
(28, 'North Carolina'),
(29, 'North Dakota'),
(30, 'Ohio'),
(31, 'Oklahoma'),
(32, 'South Carolina'),
(33, 'South Dakota'),
(34, 'Texas'),
(35, 'Virginia'),
(36, 'Washington');

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `userEmail` varchar(255) NOT NULL,
  `userIp` varbinary(16) NOT NULL,
  `city` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `loginTime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `userregistration`
--

CREATE TABLE `userregistration` (
  `id` int(11) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `middleName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `contactNo` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `regDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(45) NOT NULL,
  `passUdateDate` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hostel_id` (`hostel_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hostel`
--
ALTER TABLE `hostel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hostel_id` (`hostel_id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hostel_id` (`hostel_id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`);

--
-- Indexes for table `userregistration`
--
ALTER TABLE `userregistration`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `hostel`
--
ALTER TABLE `hostel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `userregistration`
--
ALTER TABLE `userregistration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin`
--
ALTER TABLE `admin`
  ADD CONSTRAINT `admin_ibfk_1` FOREIGN KEY (`hostel_id`) REFERENCES `hostel` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `registration`
--
ALTER TABLE `registration`
  ADD CONSTRAINT `registration_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rooms`
--
ALTER TABLE `rooms`
  ADD CONSTRAINT `rooms_ibfk_1` FOREIGN KEY (`hostel_id`) REFERENCES `hostel` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `userlog`
--
ALTER TABLE `userlog`
  ADD CONSTRAINT `userlog_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `userregistration` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
