<?php
    include '../includes/dbconn.php';
    $hid = $_SESSION['hostel_id'];
    
    $sql = "SELECT COUNT(*) as num_rows
        FROM registration AS reg
        INNER JOIN rooms AS rm ON reg.room_id = rm.id
        WHERE rm.hostel_id = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param('i', $hid);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $numRows = $row['num_rows'];
    echo $numRows;
    
?>