<?php
    include '../includes/dbconn.php';
    $hid = $_SESSION['hostel_id'];

    $sql = "SELECT COUNT(DISTINCT ur.email) AS num_emails
    FROM userregistration AS ur
    INNER JOIN registration AS reg ON ur.email = reg.emailid
    INNER JOIN rooms AS rm ON reg.room_id = rm.id
    WHERE rm.hostel_id = ?";
        $stmt = $mysqli->prepare($sql);
        $stmt->bind_param('i', $hid);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $numEmails = $row['num_emails'];
        echo $numEmails;
?>