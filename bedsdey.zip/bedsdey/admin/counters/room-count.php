<?php
    include '../includes/dbconn.php';
    $hid = $_SESSION['hostel_id'];
    
    $sql = "SELECT id FROM rooms where hostel_id = ?";
                $stmt = $mysqli->prepare($sql);
                $stmt->bind_param('i', $hid);
                $stmt->execute();
                $stmt->store_result();
                echo "$stmt->num_rows";
?>