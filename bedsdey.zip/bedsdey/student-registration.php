<?php
    session_start();
    include('includes/dbconn.php');
    if(isset($_POST['register']))
    {
    //$regno=$_POST['regno'];
    $fname=$_POST['fname'];
    $mname=$_POST['mname'];
    $lname=$_POST['lname'];
    $gender=$_POST['gender'];
    $contactno=$_POST['contact'];
    $emailid=$_POST['email'];
    $password=$_POST['password'];
    $password = md5($password);
    $query="INSERT into userRegistration(firstName,middleName,lastName,gender,contactNo,email,password) values(?,?,?,?,?,?,?)";
    $stmt = $mysqli->prepare($query);
    $rc=$stmt->bind_param('sssssss',$fname,$mname,$lname,$gender,$contactno,$emailid,$password);
    $stmt->execute();
        echo"<script>alert('Student has been Registered!');</script>";
    }
?>

<!DOCTYPE html>
<html dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title>Hostel Management System</title>
    <!-- Custom CSS -->
    <link href="dist/css/style.min.css" rel="stylesheet">

    <script type="text/javascript">
    function valid(){
        if(document.registration.password.value!= document.registration.cpassword.value)
    {
        alert("Password and Confirm Password does not match");
        document.registration.cpassword.focus();
        return false;
    }
        return true;
    }
    </script>

</head>

<body>
    <div class="main-wrapper">
        <!-- ============================================================== -->
        <!-- Preloader - style you can find in spinners.css -->
        <!-- ============================================================== -->
        <div class="preloader">
            <div class="lds-ripple">
                <div class="lds-pos"></div>
                <div class="lds-pos"></div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- Preloader - style you can find in spinners.css -->
        <!-- ============================================================== -->
        <!-- By CodeAstro - codeastro.com -->
        <!-- ============================================================== -->
        <!-- Login box.scss -->
        <!-- ============================================================== -->
        <div class="auth-wrapper d-flex no-block justify-content-center align-items-center position-relative"
            style="background:url(../assets/images/big/auth-bg.jpg) no-repeat center center;">
            <div class="auth-box row">
                <div class="col-lg-7 col-md-5 modal-bg-img" style="background-image: url(assets/images/hostel-img.jpg);">
                </div>
                <div class="col-lg-5 col-md-7 bg-white">
                    <div class="p-3">
                        <div class="text-center">
                            <img src="assets/images/big/icon.png" alt="wrapkit">
                        </div>
                    <h2 class="mt-3 text-center">Student Registration</h2>

                    <form class="mt-4" method="POST" name="registration" onSubmit="return valid();">
                        <div class="row">
                            <!--
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="text-dark" for="regno">Registration Number</label>
                                    <input class="form-control" name="regno" id="regno" type="text"
                                    required>
                                </div>
                            </div>
    -->
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="text-dark" for="fname">First Name</label>
                                    <input class="form-control" name="fname" id="fname" type="text"
                                        placeholder="Enter your first name" required>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="text-dark" for="mname">Middle Name</label>
                                    <input class="form-control" name="mname" id="mname" type="text"
                                        placeholder="Enter your middle name" required>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="text-dark" for="lname">Last Name</label>
                                    <input class="form-control" name="lname" id="lname" type="text"
                                        placeholder="Enter your last name" required>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="text-dark" for="gender">Gender</label>
                                    <div class="form-group mb-4">
                                            <select class="custom-select mr-sm-2" id="gender" name="gender" required="required">
                                                <option selected>Choose...</option>
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                            </select>
                                        </div>
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="text-dark" for="contact">Phone Number</label>
                                    <input type="text" name="contact" id="contact" placeholder="Your Contact" required="required" class="form-control">
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="text-dark" for="email">Email</label>
                                    <input type="email" name="email" id="email" placeholder="Your Email" onBlur="checkAvailability()" required="required" class="form-control">
                                            <span id="user-availability-status" style="font-size:12px;"></span>
                                </div>
                            </div>
                            
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="text-dark" for="password">Password</label>
                                    <input class="form-control" name="password" id="password" type="password"
                                        placeholder="Enter your password" required>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="text-dark" for="cpassword">Confirm Password</label>
                                    <input class="form-control" name="cpassword" id="cpassword" type="password"
                                        placeholder="Re-type your password" required>
                                </div>
                            </div>
                            <div class="col-lg-12 text-center">
                                <button type="submit" name="register" class="btn btn-block btn-dark">REGISTER</button>
                            </div>
                            <div class="col-lg-12 text-center mt-3">
                                <a href="index.php" class="text-primary">Already Registered? Login</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        </div>
        <!-- ... (remaining HTML code) ... -->
    </div>
    <script src="assets/libs/jquery/dist/jquery.min.js "></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js "></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js "></script>
    <!-- ============================================================== -->
    <!-- This page plugin js -->
    <!-- ============================================================== -->
    <script>
        $(".preloader ").fadeOut();
    </script>
    <script>
    function checkAvailability() {

        $("#loaderIcon").show();
        jQuery.ajax({
        url: "check-availability.php",
        data:'emailid='+$("#email").val(),
        type: "POST",
        success:function(data){
            $("#user-availability-status").html(data);
            $("#loaderIcon").hide();
            },
                error:function ()
            {
                event.preventDefault();
                alert('error');
            }
        });
    }
    </script>
</body>

</html>
