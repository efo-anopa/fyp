<?php
include('includes/dbconn.php'); 

if (isset($_GET['hostel'])) {
    $selectedHostelName = $_GET['hostel'];
    /*
    $stmt = $mysqli->prepare("SELECT id FROM hostel WHERE name = ?");
    $stmt->bind_param('s', $selectedHostel);
    $stmt->execute();
    $stmt->bind_result($hostelID);
    $stmt->fetch();
    $stmt->close();
    
    $query = "SELECT * FROM rooms WHERE hostel_id = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param('i', $hostelID);
    $stmt->execute();
    $res = $stmt->get_result();
    
    echo '<option selected>Select...</option>';
    while ($row = $res->fetch_object()) {
        echo '<option value="' . $row->room_no . '">' . $row->room_no . '</option>';
    }
    */
    $sql = "SELECT id FROM hostel WHERE name = '$selectedHostelName'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Fetch the id value
        $row = $result->fetch_assoc();
        $selectedHostelId = $row["id"];

        // Fetch rooms from the rooms table where hostel_id = selectedHostelId
        $sql = "SELECT * FROM rooms WHERE hostel_id = $selectedHostelId";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Generate the room options dynamically
            while ($row = $result->fetch_assoc()) {
                echo "<option value='" . $row["room_id"] . "'>" . $row["room_name"] . "</option>";
            }
        } else {
            echo "<option value=''>No rooms found</option>";
        }
    } else {
        echo "<option value=''>Invalid hostel name</option>";        }    
    $stmt->close();
}
?>
